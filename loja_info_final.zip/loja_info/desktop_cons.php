<button id="btn_bsc_Desktop">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>FABRICANTE</th>
            <th>PROCESSADOR</th>
            <th>MEMORIA RAM</th>
            <th>DISCO RIGIDO</th>
            <th>PREÇO</th>
        </tr>
    </thead>
    <tbody id="tbl_Desktop">

    </tbody>
</table>