<button id="btn_bscVenda">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>CLIENTE</th>
            <th>FUNCIONARIO</th>
            <th>EQUIPAMENTO</th>
            <th>DATA DA VENDA</th>
            <th>PRECO</th>
        </tr>
    </thead>
    <tbody id="tblVenda">

    </tbody>
</table>