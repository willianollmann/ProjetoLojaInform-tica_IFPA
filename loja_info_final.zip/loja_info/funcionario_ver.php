<button id="btn_bscFuncionario">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>NOME</th>
            <th>SOBRENOME</th>
            <th>CARGO</th>
            <th>EMAIL</th>
            <th>LOGIN</th>
            <th>SENHA</th>
        </tr>
    </thead>
    <tbody id="tblFuncionario">

    </tbody>
</table>