<button id="btn_bsc_Print">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>ABASTECIMENTO</th>
            <th>CATEGORIA</th>
            <th>PREÇO</th>
        </tr>
    </thead>
    <tbody id="tbl_Print">

    </tbody>
</table>